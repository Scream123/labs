<?php
namespace classes;

class classmain 
{
	public function __construct()
	{
		new class1();
		new class2();
	}
}