<?php
namespace classes;

class class2
{

}