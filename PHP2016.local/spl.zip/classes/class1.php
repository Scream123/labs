<?php
namespace classes;

class class1
{

}